---
name: Obsidian Grid
colors:
  surface: '#0b141c'
  surface-dim: '#0b141c'
  surface-bright: '#313a43'
  surface-container-lowest: '#060f16'
  surface-container-low: '#141c24'
  surface-container: '#182028'
  surface-container-high: '#222b33'
  surface-container-highest: '#2d363e'
  on-surface: '#dae3ee'
  on-surface-variant: '#c0c7d4'
  inverse-surface: '#dae3ee'
  inverse-on-surface: '#29313a'
  outline: '#8b919d'
  outline-variant: '#414752'
  surface-tint: '#a2c9ff'
  primary: '#a2c9ff'
  on-primary: '#00315c'
  primary-container: '#58a6ff'
  on-primary-container: '#003a6b'
  inverse-primary: '#0060aa'
  secondary: '#67df70'
  on-secondary: '#00390d'
  secondary-container: '#27a640'
  on-secondary-container: '#00320a'
  tertiary: '#d5bbff'
  on-tertiary: '#41008b'
  tertiary-container: '#b88eff'
  on-tertiary-container: '#4c069d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d3e4ff'
  primary-fixed-dim: '#a2c9ff'
  on-primary-fixed: '#001c38'
  on-primary-fixed-variant: '#004882'
  secondary-fixed: '#83fc89'
  secondary-fixed-dim: '#67df70'
  on-secondary-fixed: '#002105'
  on-secondary-fixed-variant: '#005317'
  tertiary-fixed: '#ecdcff'
  tertiary-fixed-dim: '#d5bbff'
  on-tertiary-fixed: '#270058'
  on-tertiary-fixed-variant: '#5a21ab'
  background: '#0b141c'
  on-background: '#dae3ee'
  surface-variant: '#2d363e'
typography:
  display-time:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 52px
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-badge:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
  stat-counter:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style
This design system crafts an intentional, developer-centric Android launcher and habit-tracking interface inspired by version control discipline, contribution heatmaps, and low-cognitive-load workflows. 

The aesthetic blends **Minimalism** with structural **Developer-Tool Precision**. It strips away visual noise in favor of data density, clear visual feedback loops, and thumb-friendly physical ergonomics. Surfaces are treated like pristine code environments: dark canvas backdrops, sharp semantic color indicators, and razor-thin borders replace ornamental decoration.

The system targets developers, productivity purists, and technical thinkers seeking to transform their home screen into an ambient dashboard of temporal progress and habit accountability. The experience should evoke focused calm, deliberate action, and the quiet satisfaction of maintaining an uninterrupted streak.

## Colors
The color architecture relies on a dark GitHub-inspired hierarchy designed to eliminate OLED glare while establishing high visual contrast for fast scanning on mobile devices.

### Canvas & Structural Tiers
- **Canvas / Background**: `#0D1117` provides the deep baseline canvas.
- **Surface / Container**: `#161B22` for cards, bottom sheets, and elevated overlays.
- **Surface Variant / Cell Inactive**: `#21262D` for untracked day cells, inactive toggles, and sunken input slots.
- **Borders & Dividers**: `#30363D` provides precise structural separation across all surfaces without harsh white lines.

### Text & Iconography Hierarchy
- **Primary Text**: `#E6EDF3` for high-legibility headings, task titles, and active clock digits.
- **Muted Text / Secondary**: `#8B949E` for metadata, timestamps, keyboard hints, and inactive icons.

### Contribution Grid Statuses
- **Status Complete (All Tasks Done)**: `#3FB950`
- **Status Partial (Some Tasks Done)**: `#D29922`
- **Status Incomplete (Zero Done)**: `#DA3633`
- **Status Empty / Unscheduled**: `#21262D`

### Semantic Priority Matrix
- **P1 (Urgent / Critical)**: `#A371F7`
- **P2 (High)**: `#F0883E`
- **P3 (Standard)**: `#58A6FF`
- **P4 (Backlog / Low)**: `#8B949E`

## Typography
The system employs `Inter` as the primary structural interface typeface for rapid reading and frictionless task scanning, paired with `JetBrains Mono` for tabular metrics, temporal coordinates, streak counters, and priority labels.

- Set all numerical figures to tabular lining (`font-feature-settings: "tnum"`) to guarantee stable layouts during live real-time countdowns and habit check-offs.
- `display-time` is anchored to top-level launcher lock-ups and day progress percentages.
- `label-badge` and `label-code` use uppercase styling or precise lowercase syntax with increased letter-spacing (`0.04em`) to simulate technical CLI tags.

## Layout & Spacing
Layouts follow an ergonomic bottom-weighted philosophy tuned specifically for one-handed Android usage. Interactive controls, drawer anchors, and action buttons live within the lower 60% of the viewport (the primary thumb zone), while passive ambient metrics and the year progress overview reside in the upper screen real estate.

- **Grid Structure**: A mobile single-column layout with a standardized `1rem` safe margin padding. The year habit contribution matrix utilizes a micro 7-row fluid layout with micro-gaps (`2px` to `3px`) that dynamically resize to fill screen width without vertical distortion.
- **Touch Targets**: Minimum hit area for any actionable element is strictly `48px` by `48px`, even when the visual bounding box is smaller (such as micro habit matrix days or compact list check marks).
- **Safe Area Insets**: Full support for Android gestures and cutouts. Top padding accounts for status bars (`margin-top: env(safe-area-inset-top)`), while the floating dock or sheet bottom retains a minimum `1.5rem` lift above gesture navigation strips.

## Elevation & Depth
Elevation in this design system rejects blurry drop shadows in favor of **low-contrast outlines** and **tonal layering**. This produces a crisp, hardware-native feel reminiscent of terminal windows and modern developer consoles.

- **Base Canvas (Level 0)**: `#0D1117`, flush with the display glass.
- **Elevated Surfaces (Level 1 - Cards, List Items)**: Layered with background color `#161B22` and wrapped in a crisp 1px solid border of `#30363D`.
- **Floating Overlays (Level 2 - Bottom Sheets, Search Modals, Floating Dock)**: Background `#161B22` with a 1px border of `#30363D`. Modals introduce a backdrop dimming layer of `rgba(13, 17, 23, 0.8)` with a subtle blur filter (`backdrop-filter: blur(8px)`) to obscure background clutter.
- **Zero-Shadow Rule**: Never use diffuse colored shadows or heavy black drop shadows; physical boundaries must always be declared via surface contrast and `#30363D` borders.

## Shapes
Geometry enforces functional differentiation between contextual containers, data points, and launch triggers:

- **Containers & Sheet Surfaces**: Defined by `roundedness: 2` (equivalent to a uniform `12px` / `0.75rem` radius on cards, list containers, and contextual popovers).
- **Contribution Heatmap Cells**: Hard-coded to a compact `4px` corner radius. This balances tactile softness while maintaining strict grid rhythm.
- **Dock & Persistent Action Triggers**: Rendered as pills using complete circular radii (`9999px` / `1.5rem`), creating visual affordance that distinguishes system actions from passive content cards.

## Components

### Year Contribution Matrix
- Visual: A horizontal or wrapped 7-row matrix representing 365 days.
- Sizing: Individual day nodes measure 10px to 14px square with `4px` radius and `2px` spacing.
- States: Unfilled/rest (`#21262D`), Completed (`#3FB950`), Partial (`#D29922`), Missed (`#DA3633`). Current day features an active outline pulse in `#58A6FF`.
- Interaction: Tap triggers an immediate floating bottom sheet showing date metadata and task logs for that specific day.

### Task & Habit Row Items
- Visual: Full-width list container (`#161B22`, 1px border `#30363D`, `12px` radius).
- Checkbox: Custom rounded-square (`4px` radius) with `1.5px` border in `#30363D`. When toggled, fills instantly with `#3FB950` accompanied by a checkmark in `#0D1117`.
- Metadata: Task title in `Inter 14px #E6EDF3`, priority badge, and streak tally in `JetBrains Mono 12px #8B949E`.

### Priority Badges
- Pill-shaped container (`4px` corner radius) with `0.15rem 0.4rem` interior padding.
- Structure: Alpha-tinted backgrounds (15% opacity) with 1px border matching the respective semantic priority color (`#A371F7`, `#F0883E`, `#58A6FF`, `#8B949E`).
- Typography: Strict `label-badge` (`JetBrains Mono`, 11px, bold).

### Launcher App Drawer & Search Input
- Search Field: Surface `#161B22`, border `#30363D`, placeholder text `#8B949E`. Focus state shifts the border stroke to `#58A6FF` without an outer glow.
- App Icons: Rendered with optional monochrome filtration, forcing app glyphs to `#E6EDF3` on a `#21262D` backing to preserve launcher cohesion.

### Floating Dock
- Floating pill anchored `1.5rem` above the bottom edge.
- Background `#161B22` with a `1px` border of `#30363D` and internal padding of `0.5rem 1rem`.
- Hosts quick-launcher anchors and a primary fast-add habit button using `#58A6FF` text and accenting.